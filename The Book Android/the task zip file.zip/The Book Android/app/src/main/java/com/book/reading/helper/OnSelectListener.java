package com.book.reading.helper;

public interface OnSelectListener {
    void onTextSelected(CharSequence content);
}
