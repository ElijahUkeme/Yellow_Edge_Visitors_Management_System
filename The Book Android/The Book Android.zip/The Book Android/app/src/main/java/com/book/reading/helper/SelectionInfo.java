package com.book.reading.helper;

public class SelectionInfo {
    public int mStart;
    public int mEnd;
    public String mSelectionContent;
}
